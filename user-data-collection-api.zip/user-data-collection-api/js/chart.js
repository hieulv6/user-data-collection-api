document.addEventListener('DOMContentLoaded', function() {
    const ctxRealtime = document.getElementById('realtimeChart').getContext('2d');
    const ctxDaily = document.getElementById('dailyChart').getContext('2d');

    const chartConfig = (type, labels, datasets, titleText) => ({
        type: type,
        data: { labels: labels, datasets: datasets },
        options: {
            plugins: { title: { display: true, text: titleText } },
            scales: { y: { beginAtZero: true } }
        }
    });

    const createDataset = (label, borderColor, backgroundColor = null) => ({
        label: label,
        data: [],
        borderColor: borderColor,
        borderWidth: 1,
        backgroundColor: backgroundColor
    });

    const realtimeChart = new Chart(ctxRealtime, chartConfig('line', [], [
        createDataset('iOS', 'rgba(75, 192, 192, 1)'),
        createDataset('Android', 'rgba(153, 102, 255, 1)'),
        createDataset('Desktop', 'rgba(255, 159, 64, 1)'),
        createDataset('Unknown', 'rgba(201, 203, 207, 1)')
    ], 'Số lượt truy cập (Realtime)'));

    const dailyChart = new Chart(ctxDaily, chartConfig('line', [], [
        createDataset('iOS', 'rgba(75, 192, 192, 1)', 'rgba(75, 192, 192, 0.2)'),
        createDataset('Android', 'rgba(153, 102, 255, 1)', 'rgba(153, 102, 255, 0.2)'),
        createDataset('Desktop', 'rgba(255, 159, 64, 1)', 'rgba(255, 159, 64, 0.2)'),
        createDataset('Unknown', 'rgba(201, 203, 207, 1)', 'rgba(201, 203, 207, 0.2)')
    ], 'Số lượt truy cập (Theo ngày)'));

    const updateChart = (chart, labels, datasets) => {
        chart.data.labels = labels;
        chart.data.datasets.forEach((dataset, index) => {
            dataset.data = datasets[index];
        });
        chart.update();
    };

    const fetchData = (url, callback) => {
        fetch(url)
            .then(response => response.json())
            .then(data => callback(data))
            .catch(error => console.error('Error fetching data:', error));
    };

    const updateRealtimeChart = () => {
        fetchData(userData.restUrl + '/current', data => {
            const currentTime = new Date().toLocaleTimeString();
            const counts = { iOS: 0, Android: 0, Desktop: 0, Unknown: 0 };

            data.forEach(item => {
                counts[item.platform] += item.count;
            });

            // Reset data before updating
            realtimeChart.data.labels = [];
            realtimeChart.data.datasets.forEach(dataset => dataset.data = []);

            realtimeChart.data.labels.push(currentTime);
            Object.values(counts).forEach((count, index) => {
                realtimeChart.data.datasets[index].data.push(count);
            });

            if (realtimeChart.data.labels.length > 10) {
                realtimeChart.data.labels.shift();
                realtimeChart.data.datasets.forEach(dataset => dataset.data.shift());
            }

            realtimeChart.update();
        });
    };

    const updateDailyChart = () => {
        fetchData(userData.restUrl + '/daily', data => {
            const dates = [];
            const counts = { iOS: [], Android: [], Desktop: [], Unknown: [] };

            data.forEach(item => {
                if (!dates.includes(item.date)) dates.push(item.date);
                counts[item.platform].push(item.count);
            });

            updateChart(dailyChart, dates, Object.values(counts));
        });
    };

    let currentDatasetIndex = 0;
    let showAllDatasets = false;

    const cycleDatasets = (chart) => {
        if (showAllDatasets) {
            chart.data.datasets.forEach(dataset => dataset.hidden = false);
        } else {
            chart.data.datasets.forEach((dataset, index) => {
                dataset.hidden = index !== currentDatasetIndex;
            });
            currentDatasetIndex = (currentDatasetIndex + 1) % chart.data.datasets.length;
        }
        showAllDatasets = !showAllDatasets;
        chart.update();
    };

    setInterval(updateRealtimeChart, 1000);
    setInterval(() => cycleDatasets(realtimeChart), 1000);
    updateDailyChart();

    const saveUserData = userData => {
        fetch(userData.restUrl + '/save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ data: userData })
        })
            .then(response => response.json())
            .then(data => {
                console.log('Data saved successfully:', data);
                updateRealtimeChart();
            })
            .catch(error => console.error('Error saving data:', error));
    };
});