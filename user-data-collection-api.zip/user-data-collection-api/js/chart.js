document.addEventListener('DOMContentLoaded', function () {
    var ctxRealtime = document.getElementById('realtimeChart').getContext('2d');
    var ctxDaily = document.getElementById('dailyChart').getContext('2d');

    var realtimeChart = new Chart(ctxRealtime, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Số người truy cập (Realtime)',
                data: [],
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    var dailyChart = new Chart(ctxDaily, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Số người truy cập (Theo ngày)',
                data: [],
                borderColor: 'rgba(153, 102, 255, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    function updateRealtimeChart() {
        fetch(userData.restUrl + '/current')
            .then(response => response.json())
            .then(data => {
                var currentTime = new Date().toLocaleTimeString();
                realtimeChart.data.labels.push(currentTime);
                realtimeChart.data.datasets[0].data.push(data);

                if (realtimeChart.data.labels.length > 10) {
                    realtimeChart.data.labels.shift();
                    realtimeChart.data.datasets[0].data.shift();
                }

                realtimeChart.update();
            });
    }

    function updateDailyChart() {
        fetch(userData.restUrl + '/daily')
            .then(response => response.json())
            .then(data => {
                var labels = data.map(item => item.date);
                var counts = data.map(item => item.count);

                dailyChart.data.labels = labels;
                dailyChart.data.datasets[0].data = counts;
                dailyChart.update();
            });
    }

    setInterval(updateRealtimeChart, 1000); // Cập nhật mỗi 1 giây
    updateDailyChart(); // Cập nhật dữ liệu theo ngày khi tải trang
});