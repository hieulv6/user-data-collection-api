document.addEventListener('DOMContentLoaded', () => {
    const localizedUserData = window.userData;

    const userData = {
        userAgent: navigator.userAgent,
        platform: navigator.platform,
        language: navigator.language,
        referrer: document.referrer,
        url: window.location.href,
        postType: document.querySelector('meta[name="post_type"]') ? document.querySelector('meta[name="post_type"]').content : '', 
        userId: localizedUserData.userId, 
        ip: localizedUserData.ip 
    };

    console.log('Collected User Data:', userData); // Log collected data

    const saveUserData = async () => {
    try {
        const response = await fetch(localizedUserData.restUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ data: userData })
        });

        if (!response.ok) throw new Error('Network response was not ok');
        const data = await response.json();
        console.log('Success:', data);
    } catch (error) {
        console.error('Error:', error);
        // Check if the response is available
        if (error instanceof Response) {
            const errorText = await error.text();
            console.log('Response:', errorText); // Log the response text for debugging
        }
    }
	};

    saveUserData();
});