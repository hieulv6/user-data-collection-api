Thu thập và hiển thị dữ liệu người dùng từ các bài viết.

Phiên bản 1.0.1 | Lương Văn Hiếu - Email: hieulv6@gmail.com - Bạn có thể sử dụng shortcode [display_user_data] trong bất kỳ bài viết hoặc trang nào để hiển thị dữ liệu người dùng đã thu thập được từ các bài viết.

Nếu bạn có bất kỳ câu hỏi nào khác hoặc cần thêm trợ giúp, hãy cho tôi biết nhé! 