/* 
Plugin Name: User Data Collection Plugin 
URI: https://github.com/hieulv6/user-data-collection-api 
Description: Plugin này thu thập và hiển thị dữ liệu người dùng từ các bài viết. Nó cho phép quản trị viên xem và quản lý dữ liệu người dùng, bao gồm thông tin về trình duyệt, nền tảng, ngôn ngữ, và nhiều hơn nữa. 
Bạn có thể thêm các shortcode [display_user_data], [realtime_chart], [daily_chart] vào các bài viết hoặc trang của mình để hiển thị các biểu đồ tương ứng. 
Nếu bạn có bất kỳ câu hỏi nào khác hoặc cần thêm trợ giúp, hãy cho tôi biết nhé! 
Version: 1.0.9
Author: Lương Văn Hiếu - Email: hieulv6@Gmail.com
URI: https://github.com/hieulv6 
License: GPLv2 or later License 
URI: https://www.gnu.org/licenses/gpl-2.0.html 
Text Domain: user-data-collection 
Domain Path: /languages 
*/