<?php
/*
Plugin Name: User Data Collection
Plugin URI: https://github.com/hieulv6/user-data-collection-api
Description: Plugin này thu thập và hiển thị dữ liệu người dùng từ các bài viết.
Version: 1.1.6
Author: Lương Văn Hiếu
Author URI: https://github.com/hieulv6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: user-data-collection
Domain Path: /languages
*/

/* Bạn có thể thêm các shortcode [display_user_data], [realtime_chart], [daily_chart] , [pie_chart_with_datepicker] vào các bài viết hoặc trang của mình để hiển thị các biểu đồ tương ứng. */

function user_data_collection_plugin_row_meta($links, $file) {
    if (strpos($file, 'user-data-collection.php') !== false) {
        $new_links = array(
            'version' => 'Phiên bản 1.1.6',
            'author' => 'Bởi <a href="https://github.com/hieulv6">Lương Văn Hiếu</a>',
            'details' => '<a href="https://github.com/hieulv6/user-data-collection-api">Xem chi tiết</a>'
        );
        $links = array_merge($links, $new_links);
    }
    return $links;
}
add_filter('plugin_row_meta', 'user_data_collection_plugin_row_meta', 10, 2);

// * Thêm vào dashboard
//Tạo widget tùy chỉnh trên dashboard
function custom_dashboard_widget_styles() {
    echo '
    <style>
        #custom_dashboard_widget {
            min-height: 100vh; /* Chiều cao tối thiểu là toàn màn hình */
            width: 100%;
        }
        #custom_dashboard_widget .inside {
            padding: 0;
            margin: 0;
        }
    </style>
    ';
}
add_action('admin_head', 'custom_dashboard_widget_styles');

function custom_dashboard_widget_scripts() {
    echo '
    <script>
        jQuery(document).ready(function($) {
            $("#custom_dashboard_widget").closest(".postbox").css({
                "min-height": "100vh",
                "width": "100%"
            });
        });
    </script>
    ';
}
add_action('admin_footer', 'custom_dashboard_widget_scripts');

function add_custom_dashboard_widgets() {
    wp_add_dashboard_widget(
        'custom_dashboard_widget', // Widget slug.
        'Biểu đồ truy cập', // Title.
        'custom_dashboard_widget_display' // Display function.
    );
}
add_action('wp_dashboard_setup', 'add_custom_dashboard_widgets');

function custom_dashboard_widget_display() {
    echo do_shortcode('[realtime_chart]');
    echo do_shortcode('[daily_chart]');
    echo do_shortcode('[pie_chart_with_datepicker]');
}

// Hook vào hành động 'wp_footer' để thu thập dữ liệu khi trang được tải

add_action('wp_footer', 'collect_user_data');

function collect_user_data() {
    // Register the script
    wp_register_script(
        'user-data-script',
        plugin_dir_url(__FILE__) . 'js/user-data.js',
        array('jquery'),
        null,
        true
    );

    // Get current user ID
    $current_user_id = get_current_user_id();

    // Get IP address
    $ip_address = get_user_ip_address();

    // Localize script with user data
    wp_localize_script('user-data-script', 'userData', array(
        'userId' => $current_user_id ?: null,
        'ip' => $ip_address ?: '0.0.0.0',
        'restUrl' => esc_url_raw(rest_url('user-data/v1/save'))
    ));

    // Enqueue the script
    wp_enqueue_script('user-data-script');
}

function get_user_ip_address() {
    $ip_keys = array(
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'REMOTE_ADDR'
    );

    foreach ($ip_keys as $key) {
        if (!empty($_SERVER[$key])) {
            // HTTP_X_FORWARDED_FOR có thể chứa nhiều địa chỉ IP, lấy địa chỉ đầu tiên
            $ip_list = explode(',', $_SERVER[$key]);
            foreach ($ip_list as $ip) {
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
    }

    return '0.0.0.0';
}


// Register REST API route
add_action('rest_api_init', function () {
    register_rest_route('user-data/v1', '/save', array(
        'methods' => 'POST',
        'callback' => 'save_user_data',
        'permission_callback' => '__return_true',
    ));
    register_rest_route('user-data/v1', '/current', array(
        'methods' => 'GET',
        'callback' => 'get_current_user_count',
        'permission_callback' => '__return_true',
    ));
    register_rest_route('user-data/v1', '/daily', array(
        'methods' => 'GET',
        'callback' => 'get_daily_user_count',
        'permission_callback' => '__return_true',
    ));
});

function detect_device($user_agent) {
    if (preg_match('/iPhone|iPad|iPod/', $user_agent)) {
        return 'iOS';
    } elseif (preg_match('/Android/', $user_agent)) {
        return 'Android';
    } elseif (preg_match('/Windows|Macintosh|Linux/', $user_agent)) {
        return 'Desktop';
    } else {
        return 'Unknown';
    }
}

function save_user_data(WP_REST_Request $request) {
    $data = $request->get_json_params();
    if ($data && isset($data['data']) && is_array($data['data'])) {
        $userData = $data['data']; 
        $required_fields = ['userAgent', 'platform', 'language', 'referrer', 'url', 'postType', 'userId', 'ip'];
        foreach ($required_fields as $field) {
            if (!isset($userData[$field])) {
                error_log("Missing field: $field");
                return new WP_Error('missing_field', "Missing field: $field", array('status' => 400));
            }
        }
        $device_type = detect_device($userData['userAgent']);
        global $wpdb;
        $table_name = $wpdb->prefix . 'user_data';

        error_log(print_r($userData, true));

        $result = $wpdb->insert($table_name, array(
            'user_agent' => sanitize_text_field($userData['userAgent']),
            'platform' => sanitize_text_field($device_type), 
            'language' => sanitize_text_field($userData['language']),
            'referrer' => esc_url_raw($userData['referrer']),
            'url' => esc_url_raw($userData['url']),
            'post_type' => sanitize_text_field($userData['postType']),
            'user_id' => intval($userData['userId']),
            'ip' => sanitize_text_field($userData['ip']),
            'time' => current_time('mysql')
        ));

        if ($result === false) {
            error_log('Database insert failed: ' . $wpdb->last_error);
            return new WP_Error('db_insert_error', 'Database insert failed', array('status' => 500));
        } else {
            error_log('Data inserted successfully');
            return new WP_REST_Response('Data inserted successfully', 200);
        }
    } else {
        error_log('No data received or data is not an array');
        return new WP_Error('no_data_received', 'No data received or data is not an array', array('status' => 400));
    }
}

function create_user_data_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'user_data';
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name)) != $table_name) {
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_agent text NOT NULL,
            platform text NOT NULL,
            language text NOT NULL,
            referrer text NOT NULL,
            url text NOT NULL,
            post_type text NOT NULL,
            user_id bigint(20) NOT NULL,
            ip varchar(45) NOT NULL,
            time datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}
register_activation_hook(__FILE__, 'create_user_data_table');

// Thêm menu chính và submenu cho user_data_menu
function user_data_menu() {
    add_menu_page('User Data', 'User Data', 'manage_options', 'user-data', 'display_user_data');
    add_submenu_page(
        'user-data', // Slug của menu cha
        'API Key Settings', // Tiêu đề trang
        'API Key Settings', // Tiêu đề menu
        'manage_options',   // Khả năng
        'api-key-settings', // Slug
        'render_api_key_settings_page' // Hàm hiển thị nội dung trang
    );
}
add_action('admin_menu', 'user_data_menu');

// Hàm hiển thị nội dung trang cài đặt
function render_api_key_settings_page() {
    if (isset($_POST['generate_api_key'])) {
        $duration = sanitize_text_field($_POST['duration']);
        $new_api_key = generate_api_key($duration);
        echo '<div class="updated"><p>API Key mới đã được tạo: ' . esc_html($new_api_key) . '</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>API Key Settings</h1>
        <form method="post" style="margin-bottom: 20px;">
            <input type="hidden" name="duration" value="1-year">
            <input type="submit" name="generate_api_key" class="button button-primary" value="Generate API Key for 1 Year">
        </form>
        <form method="post" style="margin-bottom: 20px;">
            <input type="hidden" name="duration" value="3-years">
            <input type="submit" name="generate_api_key" class="button button-primary" value="Generate API Key for 3 Years">
        </form>
        <form method="post" style="margin-bottom: 20px;">
            <input type="hidden" name="duration" value="5-years">
            <input type="submit" name="generate_api_key" class="button button-primary" value="Generate API Key for 5 Years">
        </form>
        <table class="widefat fixed" cellspacing="0">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>API Key</th>
                    <th>Expiry Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                global $wpdb;
                $table_name = $wpdb->prefix . 'api_keys';
                $results = $wpdb->get_results("SELECT * FROM $table_name");
                foreach ($results as $row) {
                    echo '<tr>';
                    echo '<td>' . esc_html($row->id) . '</td>';
                    echo '<td>' . esc_html($row->api_key) . '</td>';
                    echo '<td>' . esc_html($row->expiry_date) . '</td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php
}

// Hàm tạo API key
function generate_api_key($duration) {
    $api_key = bin2hex(random_bytes(16));
    $current_date = date('Y-m-d');
    $expiry_date = '';

    switch ($duration) {
        case '1-year':
            $expiry_date = date('Y-m-d', strtotime('+1 year', strtotime($current_date)));
            break;
        case '3-years':
            $expiry_date = date('Y-m-d', strtotime('+3 years', strtotime($current_date)));
            break;
        case '5-years':
            $expiry_date = date('Y-m-d', strtotime('+5 years', strtotime($current_date)));
            break;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'api_keys';
    $wpdb->insert($table_name, array(
        'api_key' => $api_key,
        'expiry_date' => $expiry_date,
    ));

    return $api_key;
}

// Hàm tạo bảng API keys
function create_api_keys_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'api_keys';
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name)) != $table_name) {
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            api_key varchar(32) NOT NULL,
            expiry_date date NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}
register_activation_hook(__FILE__, 'create_api_keys_table');

// Thêm API key vào biến localizedUserData
function add_localized_user_data() {
    $current_user_id = get_current_user_id();
    $user_ip = $_SERVER['REMOTE_ADDR'];
    $api_key = get_option('current_api_key'); // Giả sử bạn lưu API key hiện tại trong tùy chọn

    wp_localize_script('your-script-handle', 'userData', array(
        'userId' => $current_user_id,
        'ip' => $user_ip,
        'restUrl' => rest_url('user-data/v1/save'),
        'apiKey' => $api_key // Thêm API key vào đây
    ));
}
add_action('wp_enqueue_scripts', 'add_localized_user_data');

function get_current_user_count() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'user_data';
    $local_time = current_time('mysql'); // Lấy thời gian theo múi giờ địa phương
    $utc_time = gmdate('Y-m-d H:i:s', strtotime($local_time)); // Chuyển đổi sang UTC

    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT platform, COUNT(*) as count FROM $table_name WHERE time >= DATE_SUB(%s, INTERVAL 5 MINUTE) GROUP BY platform",
        $utc_time
    ));

    $data = array();
    foreach ($results as $row) {
        $data[] = array(
            'platform' => $row->platform,
            'count' => $row->count
        );
    }

    return new WP_REST_Response($data, 200);
}

function get_daily_user_count() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'user_data';
    $results = $wpdb->get_results("SELECT platform, COUNT(*) as count, DATE(time) as date FROM $table_name GROUP BY platform, DATE(time)");
    $data = array();

    foreach ($results as $result) {
        $data[] = array(
            'date' => $result->date,
            'platform' => $result->platform,
            'count' => $result->count
        );
    }
    return new WP_REST_Response($data, 200);
}

function get_url_views_data() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'user_data';

    // Lấy dữ liệu lượt xem theo ngày
    $daily_views = $wpdb->get_results("
        SELECT url, DATE(time) as date, COUNT(*) as views
        FROM $table_name
        GROUP BY url, DATE(time)
    ");

    // Lấy dữ liệu lượt xem theo tháng
    $monthly_views = $wpdb->get_results("
        SELECT url, DATE_FORMAT(time, '%Y-%m') as month, COUNT(*) as views
        FROM $table_name
        GROUP BY url, DATE_FORMAT(time, '%Y-%m')
    ");

    return array('daily' => $daily_views, 'monthly' => $monthly_views);
}

function display_user_data() {
    global $wpdb;
    $current_user_id = get_current_user_id();
    $table_name = $wpdb->prefix . 'user_data';

    echo '<div style="display: block; justify-content: space-around; margin-bottom: 20px;">';
    echo '<div style="width: 100%;">' . do_shortcode('[realtime_chart]') . '</div>';
    echo '<div style="width: 100%;">' . do_shortcode('[daily_chart]') . '</div>';
	echo '<div style="width: 100%;">' . do_shortcode('[pie_chart_with_datepicker]') . '</div>';
	echo '<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>';
    echo '<script src="' . plugin_dir_url(__FILE__) . 'js/chart.js"></script>';
    echo '</div>';

    if (current_user_can('administrator') && isset($_POST['delete_selected'])) {
        if (!empty($_POST['data_ids'])) {
            $ids = implode(',', array_map('intval', $_POST['data_ids']));
            $wpdb->query("DELETE FROM $table_name WHERE id IN ($ids)");
            echo '<div class="updated"><p>Dữ liệu đã được xóa thành công.</p></div>';
        }
    } elseif (current_user_can('administrator') && isset($_POST['delete_all'])) {
        $wpdb->query("DELETE FROM $table_name");
        echo '<div class="updated"><p>Tất cả dữ liệu đã được xóa thành công.</p></div>';
    }

    $selected_roles = get_option('user_data_roles', []);
    if (current_user_can('administrator')) {
        $results = $wpdb->get_results("SELECT * FROM $table_name");
    } else {
        $results = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d OR user_id IN (SELECT post_author FROM {$wpdb->prefix}posts WHERE ID = %d)", $current_user_id, $current_user_id));
    }

    echo '<div class="wrap">';
    echo '<h1>User Data</h1>';
    echo '<form method="post">';
    if (current_user_can('administrator')) {
        echo '<input class="d-none" type="submit" name="delete_all" value="Xóa Tất Cả Dữ Liệu" class="button button-primary" onclick="return confirm(\'Bạn có chắc chắn muốn xóa tất cả dữ liệu không?\')">';
    }
    echo '<table class="widefat fixed" cellspacing="0">';
    echo '<thead><tr><th class="d-none"><input type="checkbox" id="select_all"></th><th class="d-none">ID</th><th class="d-none">User Agent</th><th class="d-none">Platform</th><th class="d-none">Language</th><th class="d-none">Referrer</th><th class="d-none">URL</th><th class="d-none">Post Type</th><th class="d-none">IP</th><th class="d-none">Time</th></tr></thead>';
    echo '<tbody>';
    foreach ($results as $row) {
        echo '<tr>';
        echo '<td class="d-none"><input type="checkbox" name="data_ids[]" value="' . $row->id . '"></td>';
        echo '<td class="d-none">' . $row->id . '</td>';
        echo '<td class="d-none">' . $row->user_agent . '</td>';
        echo '<td class="d-none">' . $row->platform . '</td>';
        echo '<td class="d-none">' . $row->language . '</td>';
        echo '<td class="d-none">' . $row->referrer . '</td>';
        echo '<td class="d-none">' . $row->url . '</td>';
        echo '<td class="d-none">' . $row->post_type . '</td>';
        echo '<td class="d-none">' . $row->ip . '</td>';
        echo '<td class="d-none">' . $row->time . '</td>';
        echo '</tr>';
    }
    echo '</tbody>';
    echo '</table>';
    if (current_user_can('administrator')) {
        echo '<input class="d-none" type="submit" name="delete_selected" value="Xóa Dữ Liệu Đã Chọn" class="button button-secondary" onclick="return confirm(\'Bạn có chắc chắn muốn xóa dữ liệu đã chọn không?\')">';
    }
    echo '</form>';
    echo '</div>';
}


add_shortcode('display_user_data', 'display_user_data_shortcode');

//JavaScript để chọn tất cả checkbox
add_action('admin_footer', 'add_select_all_script');
function add_select_all_script() {
    echo '<script type="text/javascript">
    jQuery(document).ready(function($) {
        $("#select_all").click(function() {
            $("input[name=\'data_ids[]\']").prop("checked", this.checked);
        });
    });
    </script>';
}

// Shortcode display_user_data
function display_user_data_shortcode() {
    ob_start();
    display_user_data();
    return ob_get_clean();
}
add_shortcode('display_user_data', 'display_user_data_shortcode');

// Shortcode [display_realtime_chart]
function display_realtime_chart() {
    ob_start();
    ?>
    <canvas id="realtimeChart" width="400" height="200"></canvas>
    <script>
	document.addEventListener('DOMContentLoaded', function() {
    var ctx = document.getElementById('realtimeChart').getContext('2d');
    var realtimeChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                {
                    label: 'iOS',
                    data: [],
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Android',
                    data: [],
                    borderColor: 'rgba(153, 102, 255, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Desktop',
                    data: [],
                    borderColor: 'rgba(255, 159, 64, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Unknown',
                    data: [],
                    borderColor: 'rgba(201, 203, 207, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            plugins: {
                title: {
                    display: true,
                    text: 'Số lượt truy cập (Realtime)'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    function updateRealtimeChart() {
        fetch('<?php echo esc_url(rest_url('user-data/v1/current')); ?>')
            .then(response => response.json())
            .then(data => {
                if (!Array.isArray(data)) {
                    console.error('Expected an array but got:', data);
                    return;
                }

                var currentTime = new Date().toLocaleTimeString();
                var iosCount = 0;
                var androidCount = 0;
                var desktopCount = 0;
                var unknownCount = 0;

                data.forEach(item => {
                    switch (item.platform) {
                        case 'iOS':
                            iosCount += item.count;
                            break;
                        case 'Android':
                            androidCount += item.count;
                            break;
                        case 'Desktop':
                            desktopCount += item.count;
                            break;
                        case 'Unknown':
                            unknownCount += item.count;
                            break;
                    }
                });

                // Thêm dữ liệu mới mà không reset dữ liệu cũ
                realtimeChart.data.labels.push(currentTime);
                realtimeChart.data.datasets[0].data.push(iosCount);
                realtimeChart.data.datasets[1].data.push(androidCount);
                realtimeChart.data.datasets[2].data.push(desktopCount);
                realtimeChart.data.datasets[3].data.push(unknownCount);

                if (realtimeChart.data.labels.length > 10) {
                    realtimeChart.data.labels.shift();
                    realtimeChart.data.datasets.forEach(dataset => dataset.data.shift());
                }

                realtimeChart.update();
            })
            .catch(error => console.error('Error fetching data:', error));
    }

    setInterval(updateRealtimeChart, 1000);
});
</script>
    <?php
    return ob_get_clean();
}
add_shortcode('realtime_chart', 'display_realtime_chart');

// Shortcode [display_daily_chart]
function display_daily_chart() {
    ob_start();
    ?>
    <canvas id="dailyChart" width="400" height="200"></canvas>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var ctx = document.getElementById('dailyChart').getContext('2d');
            var dailyChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [
                        {
                            label: 'iOS',
                            data: [],
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            borderColor: 'rgba(75, 192, 192, 1)',
                            borderWidth: 1
                        },
                        {
                            label: 'Android',
                            data: [],
                            backgroundColor: 'rgba(153, 102, 255, 0.2)',
                            borderColor: 'rgba(153, 102, 255, 1)',
                            borderWidth: 1
                        },
                        {
                            label: 'Desktop',
                            data: [],
                            backgroundColor: 'rgba(255, 159, 64, 0.2)',
                            borderColor: 'rgba(255, 159, 64, 1)',
                            borderWidth: 1
                        },
                        {
                            label: 'Unknown',
                            data: [],
                            backgroundColor: 'rgba(201, 203, 207, 0.2)',
                            borderColor: 'rgba(201, 203, 207, 1)',
                            borderWidth: 1
                        }
                    ]
                },
                options: {
                    plugins: {
                        title: {
                            display: true,
                            text: 'Số lượt truy cập (Theo ngày)'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            var currentDatasetIndex = 0;
            var showAllDatasets = false;

            function updateDailyChart() {
                fetch('<?php echo esc_url(rest_url('user-data/v1/daily')); ?>')
                    .then(response => response.json())
                    .then(data => {
                        var dates = [];
                        var iosData = [];
                        var androidData = [];
                        var desktopData = [];
                        var unknownData = [];

                        data.forEach(item => {
                            if (!dates.includes(item.date)) {
                                dates.push(item.date);
                            }
                            switch (item.platform) {
                                case 'iOS':
                                    iosData.push(item.count);
                                    break;
                                case 'Android':
                                    androidData.push(item.count);
                                    break;
                                case 'Desktop':
                                    desktopData.push(item.count);
                                    break;
                                case 'Unknown':
                                    unknownData.push(item.count);
                                    break;
                            }
                        });

                        dailyChart.data.labels = dates;
                        dailyChart.data.datasets[0].data = iosData;
                        dailyChart.data.datasets[1].data = androidData;
                        dailyChart.data.datasets[2].data = desktopData;
                        dailyChart.data.datasets[3].data = unknownData;

                        dailyChart.update();
                    });
            }

            function cycleDatasets() {
                if (showAllDatasets) {
                    dailyChart.data.datasets.forEach(dataset => dataset.hidden = false);
                    showAllDatasets = false;
                } else {
                    dailyChart.data.datasets.forEach((dataset, index) => {
                        dataset.hidden = index !== currentDatasetIndex;
                    });
                    currentDatasetIndex = (currentDatasetIndex + 1) % dailyChart.data.datasets.length;
                    if (currentDatasetIndex === 0) {
                        showAllDatasets = true;
                    }
                }
                dailyChart.update();
            }

            setInterval(updateDailyChart, 1000);
        });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('daily_chart', 'display_daily_chart');

//Hiển thị biểu đồ số lượt xem Url
add_action('wp_ajax_get_filtered_data', 'get_filtered_data');
add_action('wp_ajax_nopriv_get_filtered_data', 'get_filtered_data');

function get_filtered_data() {
    $start_date = isset($_POST['start_date']) ? sanitize_text_field($_POST['start_date']) : '';
    $end_date = isset($_POST['end_date']) ? sanitize_text_field($_POST['end_date']) : '';

    $data = get_url_views_data(); // Thay thế bằng logic thực tế để lấy dữ liệu từ cơ sở dữ liệu

    $filtered_data = array_filter($data['daily'], function($item) use ($start_date, $end_date) {
        return $item->date >= $start_date && $item->date <= $end_date;
    });

    if (empty($filtered_data)) {
        wp_send_json_error(array('message' => 'Không có dữ liệu!'));
        return;
    }

    $labels = array_map(function($item) { return $item->url; }, $filtered_data); // Chỉ giữ lại URL gốc
    $views = array_map(function($item) { return $item->views; }, $filtered_data);

    wp_send_json_success(array('labels' => $labels, 'data' => $views));
}

function create_pie_chart_with_datepicker($data, $labels, $title) {
    ob_start();
    ?>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <div class="chart-container" style="padding: 10px; max-width: 100%; margin: auto; box-sizing: border-box;">
    <p style="margin-bottom: 10px;">Chọn khoảng thời gian hiển thị số lượt xem URL:</p>
    <label for="start_date" style="display: block; margin-bottom: 5px;">Từ ngày:</label>
    <input type="date" id="start_date" style="width: 100%; margin-bottom: 10px; padding: 8px; box-sizing: border-box;">
    <label for="end_date" style="display: block; margin-bottom: 5px;">Đến ngày:</label>
    <input type="date" id="end_date" style="width: 100%; margin-bottom: 10px; padding: 8px; box-sizing: border-box;">
    <button style="background-color:#F7841B; color:white; border-radius:5px; cursor:pointer; padding:10px; border: 2px solid #F7841B; width: 100%; box-sizing: border-box;" onclick="showChart()">Xem biểu đồ</button>
</div>
<div id="chart_container" class="chart-container" style="width: 100%; height: 400px; box-sizing: border-box;"></div>
    <script>
        $(function() {
            $("#start_date, #end_date").datepicker({
                dateFormat: "yy-mm-dd"
            });
        });

        function showChart() {
            var startDate = document.getElementById('start_date').value;
            var endDate = document.getElementById('end_date').value;
            var chartContainer = document.getElementById('chart_container');
            chartContainer.innerHTML = '';

            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                method: 'POST',
                data: {
                    action: 'get_filtered_data',
                    start_date: startDate,
                    end_date: endDate
                },
                success: function(response) {
                    if (response.success) {
                        var labels = response.data.labels;
                        var data = response.data.data;

                        if (labels.length === 0 || data.length === 0) {
                            chartContainer.innerHTML = '<p>Không có dữ liệu!</p>';
                            return;
                        }

                        var ctx = document.createElement('canvas');
                        chartContainer.appendChild(ctx);

                        new Chart(ctx, {
                            type: 'pie',
                            data: {
                                labels: labels,
                                datasets: [{
                                    data: data,
                                    backgroundColor: [
                                        'rgba(255, 99, 132, 0.2)',
                                        'rgba(54, 162, 235, 0.2)',
                                        'rgba(255, 206, 86, 0.2)',
                                        'rgba(75, 192, 192, 0.2)',
                                        'rgba(153, 102, 255, 0.2)',
                                        'rgba(255, 159, 64, 0.2)'
                                    ],
                                    borderColor: [
                                        'rgba(255, 99, 132, 1)',
                                        'rgba(54, 162, 235, 1)',
                                        'rgba(255, 206, 86, 1)',
                                        'rgba(75, 192, 192, 1)',
                                        'rgba(153, 102, 255, 1)',
                                        'rgba(255, 159, 64, 1)'
                                    ],
                                    borderWidth: 1
                                }]
                            },
                            options: {
                                title: {
                                    display: true,
                                    text: 'Hiển thị số lượt xem Url'
                                },
                                responsive: true,
                                maintainAspectRatio: false,
                                onClick: function(evt, item) {
                                    if (item.length > 0) {
                                        var index = item[0].index;
                                        var url = labels[index];
                                        window.open(url, '_blank');
                                    }
                                }
                            }
                        });
                    } else {
                        chartContainer.innerHTML = '<p>' + response.data.message + '</p>';
                    }
                },
                error: function() {
                    chartContainer.innerHTML = '<p>Đã xảy ra lỗi khi tải dữ liệu.</p>';
                }
            });
        }

        var ctx = document.getElementById('<?php echo sanitize_title($title); ?>').getContext('2d');
        var pieChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($labels); ?>,
                datasets: [{
                    data: <?php echo json_encode($data); ?>,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                title: {
                    display: true,
                    text: 'Hiển thị số lượt xem Url'
                },
                responsive: true,
                maintainAspectRatio: false,
                onClick: function(evt, item) {
                    if (item.length > 0) {
                        var index = item[0].index;
                        var url = <?php echo json_encode($labels); ?>[index];
                        window.open(url, '_blank');
                    }
                }
            }
        });
    </script>
    <?php
    return ob_get_clean();
}

add_shortcode('pie_chart_with_datepicker', function() {
    return create_pie_chart_with_datepicker([], [], 'Biểu đồ mẫu');
});


?>
