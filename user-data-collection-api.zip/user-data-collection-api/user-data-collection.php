<?php
/*
Plugin Name: User Data Collection
Plugin URI: https://github.com/hieulv6/user-data-collection-api
Description: Plugin này thu thập và hiển thị dữ liệu người dùng từ các bài viết. Nó cho phép quản trị viên xem và quản lý dữ liệu người dùng, bao gồm thông tin về trình duyệt, nền tảng, ngôn ngữ, và nhiều hơn nữa. Bạn có thể sử dụng shortcode [display_user_data] trong bất kỳ bài viết hoặc trang nào để hiển thị dữ liệu người dùng đã thu thập được từ các bài viết.
Nếu bạn có bất kỳ câu hỏi nào khác hoặc cần thêm trợ giúp, hãy cho tôi biết nhé! 
Version: 1.0.2
Author: Lương Văn Hiếu
Author URI: https://github.com/hieulv6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: user-data-collection
Domain Path: /languages
*/

// Hook vào hành động 'wp_footer' để thu thập dữ liệu khi trang được tải
add_action('wp_footer', 'collect_user_data');

function collect_user_data() {
    wp_register_script('user-data-script', plugin_dir_url(__FILE__) . 'js/user-data.js', array('jquery'), null, true);

    $current_user_id = get_current_user_id();
    $ip_address = '';

    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip_address = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
        $ip_address = $_SERVER['REMOTE_ADDR'];
    } else {
        $ip_address = '0.0.0.0'; 
    }

    wp_localize_script('user-data-script', 'userData', array(
        'userId' => $current_user_id ? $current_user_id : null,
        'ip' => $ip_address ? $ip_address : '0.0.0.0',
        'restUrl' => esc_url_raw(rest_url('user-data/v1/save'))
    ));

    wp_enqueue_script('user-data-script');
}

// Register REST API route
add_action('rest_api_init', function () {
    register_rest_route('user-data/v1', '/save', array(
        'methods' => 'POST',
        'callback' => 'save_user_data',
        'permission_callback' => '__return_true',
    ));
});

function save_user_data(WP_REST_Request $request) {
    $data = $request->get_json_params();
    if ($data && isset($data['data'])) {
        $userData = $data['data']; 

        // Validate required fields
        $required_fields = ['userAgent', 'platform', 'language', 'referrer', 'url', 'postType', 'userId', 'ip'];
        foreach ($required_fields as $field) {
            if (!isset($userData[$field])) {
                error_log("Missing field: $field");
                return new WP_Error('missing_field', "Missing field: $field", array('status' => 400));
            }
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'user_data';

        error_log(print_r($userData, true));

        $result = $wpdb->insert($table_name, array(
            'user_agent' => $userData['userAgent'],
            'platform' => $userData['platform'],
            'language' => $userData['language'],
            'referrer' => $userData['referrer'],
            'url' => $userData['url'],
            'post_type' => $userData['postType'],
            'user_id' => $userData['userId'],
            'ip' => $userData['ip'],
            'time' => current_time('mysql')
        ));

        if ($result === false) {
            error_log('Database insert failed: ' . $wpdb->last_error);
            return new WP_Error('db_insert_error', 'Database insert failed', array('status' => 500));
        } else {
            error_log('Data inserted successfully');
            return new WP_REST_Response('Data inserted successfully', 200);
        }
    } else {
        error_log('No data received');
        return new WP_Error('no_data_received', 'No data received', array('status' => 400));
    }
}

register_activation_hook(__FILE__, 'create_user_data_table');

function create_user_data_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'user_data';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_agent text NOT NULL,
            platform text NOT NULL,
            language text NOT NULL,
            referrer text NOT NULL,
            url text NOT NULL,
            post_type text NOT NULL,
            user_id bigint(20) NOT NULL,
            ip varchar(45) NOT NULL,
            time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}

add_action('admin_menu', 'user_data_menu');

function user_data_menu() {
    add_menu_page('User Data', 'User Data', 'manage_options', 'user-data', 'display_user_data');
}

function display_user_data() {
    global $wpdb;
    $current_user_id = get_current_user_id();
    $table_name = $wpdb->prefix . 'user_data';

    if (isset($_POST['delete_selected'])) {
        if (!empty($_POST['data_ids'])) {
            $ids = implode(',', array_map('intval', $_POST['data_ids']));
            $wpdb->query("DELETE FROM $table_name WHERE id IN ($ids)");
            echo '<div class="updated"><p>Dữ liệu đã được xóa thành công.</p></div>';
        }
    } elseif (isset($_POST['delete_all'])) {
        $wpdb->query("DELETE FROM $table_name");
        echo '<div class="updated"><p>Tất cả dữ liệu đã được xóa thành công.</p></div>';
    }

    if (current_user_can('administrator')) {
        $results = $wpdb->get_results("SELECT * FROM $table_name");
    } else {
        $results = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d", $current_user_id));
    }

    echo '<div class="wrap">';
    echo '<h1>User Data</h1>';
    echo '<form method="post">';
    echo '<input type="submit" name="delete_all" value="Xóa Tất Cả Dữ Liệu" class="button button-primary" onclick="return confirm(\'Bạn có chắc chắn muốn xóa tất cả dữ liệu không?\')">';
    echo '<table class="widefat fixed" cellspacing="0">';
    echo '<thead><tr><th><input type="checkbox" id="select_all"></th><th>ID</th><th>User Agent</th><th>Platform</th><th>Language</th><th>Referrer</th><th>URL</th><th>Post Type</th><th>IP</th><th>Time</th></tr></thead>';
    echo '<tbody>';
    foreach ($results as $row) {
        echo '<tr>';
        echo '<td><input type="checkbox" name="data_ids[]" value="' . $row->id . '"></td>';
        echo '<td>' . $row->id . '</td>';
        echo '<td>' . $row->user_agent . '</td>';
        echo '<td>' . $row->platform . '</td>';
        echo '<td>' . $row->language . '</td>';
        echo '<td>' . $row->referrer . '</td>';
        echo '<td>' . $row->url . '</td>';
        echo '<td>' . $row->post_type . '</td>';
        echo '<td>' . $row->ip . '</td>';
        echo '<td>' . $row->time . '</td>';
        echo '</tr>';
    }
    echo '</tbody>';
    echo '</table>';
    echo '<input type="submit" name="delete_selected" value="Xóa Dữ Liệu Đã Chọn" class="button button-secondary" onclick="return confirm(\'Bạn có chắc chắn muốn xóa dữ liệu đã chọn không?\')">';
    echo '</form>';
    echo '</div>';
}

add_shortcode('display_user_data', 'display_user_data_shortcode');

//JavaScript để chọn tất cả checkbox
add_action('admin_footer', 'add_select_all_script');
function add_select_all_script() {
    echo '<script type="text/javascript">
    jQuery(document).ready(function($) {
        $("#select_all").click(function() {
            $("input[name=\'data_ids[]\']").prop("checked", this.checked);
        });
    });
    </script>';
}

// Shortcode display_user_data
function display_user_data_shortcode() {
    ob_start();
    display_user_data();
    return ob_get_clean();
}
?>