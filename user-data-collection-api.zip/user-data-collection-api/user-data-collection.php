<?php
/*
Plugin Name: User Data Collection
Plugin URI: https://github.com/hieulv6/user-data-collection-api
Description: Plugin này thu thập và hiển thị dữ liệu người dùng từ các bài viết.
Version: 1.0.9
Author: Lương Văn Hiếu
Author URI: https://github.com/hieulv6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: user-data-collection
Domain Path: /languages
*/

/* Bạn có thể thêm các shortcode [display_user_data], [realtime_chart], và [daily_chart] vào các bài viết hoặc trang của mình để hiển thị các biểu đồ tương ứng. */

function user_data_collection_plugin_row_meta($links, $file) {
    if (strpos($file, 'user-data-collection.php') !== false) {
        $new_links = array(
            'version' => 'Phiên bản 1.0.9',
            'author' => 'Bởi <a href="https://github.com/hieulv6">Lương Văn Hiếu</a>',
            'details' => '<a href="https://github.com/hieulv6/user-data-collection-api">Xem chi tiết</a>'
        );
        $links = array_merge($links, $new_links);
    }
    return $links;
}
add_filter('plugin_row_meta', 'user_data_collection_plugin_row_meta', 10, 2);

// Hook vào hành động 'wp_footer' để thu thập dữ liệu khi trang được tải

add_action('wp_footer', 'collect_user_data');

function collect_user_data() {
    wp_register_script('user-data-script', plugin_dir_url(__FILE__) . 'js/user-data.js', array('jquery'), null, true);

    $current_user_id = get_current_user_id();
    $ip_address = '';

    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip_address = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
        $ip_address = $_SERVER['REMOTE_ADDR'];
    } else {
        $ip_address = '0.0.0.0'; 
    }

    wp_localize_script('user-data-script', 'userData', array(
        'userId' => $current_user_id ? $current_user_id : null,
        'ip' => $ip_address ? $ip_address : '0.0.0.0',
        'restUrl' => esc_url_raw(rest_url('user-data/v1/save'))
    ));

    wp_enqueue_script('user-data-script');
}

// Register REST API route
add_action('rest_api_init', function () {
    register_rest_route('user-data/v1', '/save', array(
        'methods' => 'POST',
        'callback' => 'save_user_data',
        'permission_callback' => '__return_true',
    ));
    register_rest_route('user-data/v1', '/current', array(
        'methods' => 'GET',
        'callback' => 'get_current_user_count',
        'permission_callback' => '__return_true',
    ));
    register_rest_route('user-data/v1', '/daily', array(
        'methods' => 'GET',
        'callback' => 'get_daily_user_count',
        'permission_callback' => '__return_true',
    ));
});

function save_user_data(WP_REST_Request $request) {
    $data = $request->get_json_params();
    if ($data && isset($data['data'])) {
        $userData = $data['data']; 

        // Validate required fields
        $required_fields = ['userAgent', 'platform', 'language', 'referrer', 'url', 'postType', 'userId', 'ip'];
        foreach ($required_fields as $field) {
            if (!isset($userData[$field])) {
                error_log("Missing field: $field");
                return new WP_Error('missing_field', "Missing field: $field", array('status' => 400));
            }
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'user_data';

        error_log(print_r($userData, true));

        $result = $wpdb->insert($table_name, array(
            'user_agent' => $userData['userAgent'],
            'platform' => $userData['platform'],
            'language' => $userData['language'],
            'referrer' => $userData['referrer'],
            'url' => $userData['url'],
            'post_type' => $userData['postType'],
            'user_id' => $userData['userId'],
            'ip' => $userData['ip'],
            'time' => current_time('mysql')
        ));

        if ($result === false) {
            error_log('Database insert failed: ' . $wpdb->last_error);
            return new WP_Error('db_insert_error', 'Database insert failed', array('status' => 500));
        } else {
            error_log('Data inserted successfully');
            return new WP_REST_Response('Data inserted successfully', 200);
        }
    } else {
        error_log('No data received');
        return new WP_Error('no_data_received', 'No data received', array('status' => 400));
    }
}
register_activation_hook(__FILE__, 'create_user_data_table');

function create_user_data_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'user_data';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_agent text NOT NULL,
            platform text NOT NULL,
            language text NOT NULL,
            referrer text NOT NULL,
            url text NOT NULL,
            post_type text NOT NULL,
            user_id bigint(20) NOT NULL,
            ip varchar(45) NOT NULL,
            time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}

add_action('admin_menu', 'user_data_menu');

function user_data_menu() {
    add_menu_page('User Data', 'User Data', 'manage_options', 'user-data', 'display_user_data');
    add_submenu_page('user-data', 'Settings', 'Settings', 'manage_options', 'user-data-settings', 'user_data_settings');
}

function get_current_user_count() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'user_data';
    $current_time = current_time('mysql');
    $count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE time >= DATE_SUB('$current_time', INTERVAL 5 MINUTE)");
    return new WP_REST_Response($count, 200);
}

function get_daily_user_count() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'user_data';
    $results = $wpdb->get_results("SELECT COUNT(*) as count, DATE(time) as date FROM $table_name GROUP BY DATE(time)");
    return new WP_REST_Response($results, 200);
}

function display_user_data() {
    global $wpdb;
    $current_user_id = get_current_user_id();
    $table_name = $wpdb->prefix . 'user_data';
	
	// Định nghĩa biến userData
    $rest_url = esc_url_raw(rest_url('user-data/v1'));
    echo '<script>';
    echo 'var userData = { restUrl: "' . $rest_url . '" };';
    echo '</script>';

    echo '<div class="wrap">';
    echo '<h1>User Data</h1>';
    echo '<div style="display: flex; justify-content: space-around;">';
    echo '<div>';
    echo '<h2>Realtime</h2>';
    echo '<canvas id="realtimeChart" width="400" height="200"></canvas>';
    echo '</div>';
    echo '<div>';
    echo '<h2>Theo ngày</h2>';
    echo '<canvas id="dailyChart" width="400" height="200"></canvas>';
    echo '</div>';
    echo '</div>';
    echo '<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>';
    echo '<script src="' . plugin_dir_url(__FILE__) . 'js/chart.js"></script>';
    echo '</div>';
	
    if (current_user_can('administrator') && isset($_POST['delete_selected'])) {
        if (!empty($_POST['data_ids'])) {
            $ids = implode(',', array_map('intval', $_POST['data_ids']));
            $wpdb->query("DELETE FROM $table_name WHERE id IN ($ids)");
            echo '<div class="updated"><p>Dữ liệu đã được xóa thành công.</p></div>';
        }
    } elseif (current_user_can('administrator') && isset($_POST['delete_all'])) {
        $wpdb->query("DELETE FROM $table_name");
        echo '<div class="updated"><p>Tất cả dữ liệu đã được xóa thành công.</p></div>';
    }

    $selected_roles = get_option('user_data_roles', []);
    if (current_user_can('administrator')) {
        $results = $wpdb->get_results("SELECT * FROM $table_name");
    } else {
        $results = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d OR user_id IN (SELECT post_author FROM {$wpdb->prefix}posts WHERE ID = %d)", $current_user_id, $current_user_id));
    }

    echo '<div class="wrap">';
    echo '<h1>User Data</h1>';
    echo '<form method="post">';
    if (current_user_can('administrator')) {
        echo '<input type="submit" name="delete_all" value="Xóa Tất Cả Dữ Liệu" class="button button-primary" onclick="return confirm(\'Bạn có chắc chắn muốn xóa tất cả dữ liệu không?\')">';
    }
    echo '<table class="widefat fixed" cellspacing="0">';
    echo '<thead><tr><th><input type="checkbox" id="select_all"></th><th>ID</th><th>User Agent</th><th>Platform</th><th>Language</th><th>Referrer</th><th>URL</th><th>Post Type</th><th>IP</th><th>Time</th></tr></thead>';
    echo '<tbody>';
    foreach ($results as $row) {
        echo '<tr>';
        echo '<td><input type="checkbox" name="data_ids[]" value="' . $row->id . '"></td>';
        echo '<td>' . $row->id . '</td>';
        echo '<td>' . $row->user_agent . '</td>';
        echo '<td>' . $row->platform . '</td>';
        echo '<td>' . $row->language . '</td>';
        echo '<td>' . $row->referrer . '</td>';
        echo '<td>' . $row->url . '</td>';
        echo '<td>' . $row->post_type . '</td>';
        echo '<td>' . $row->ip . '</td>';
        echo '<td>' . $row->time . '</td>';
        echo '</tr>';
    }
    echo '</tbody>';
    echo '</table>';
    if (current_user_can('administrator')) {
        echo '<input type="submit" name="delete_selected" value="Xóa Dữ Liệu Đã Chọn" class="button button-secondary" onclick="return confirm(\'Bạn có chắc chắn muốn xóa dữ liệu đã chọn không?\')">';
    }
    echo '</form>';
    echo '</div>';
}

function user_data_settings() {
    echo '<div class="wrap">';
    echo '<h1>Settings</h1>';
    echo '<form method="post" action="options.php">';
    settings_fields('user_data_settings_group');
    do_settings_sections('user_data_settings_group');
    submit_button();
    echo '</form>';
    echo '</div>';
}

add_action('admin_init', 'user_data_settings_init');

function user_data_settings_init() {
    register_setting('user_data_settings_group', 'user_data_roles');

    add_settings_section('user_data_settings_section', 'User Data Settings', 'user_data_settings_section_callback', 'user_data_settings_group');

    add_settings_field('user_data_roles', 'Roles', 'user_data_roles_callback', 'user_data_settings_group', 'user_data_settings_section');
}

function user_data_settings_section_callback() {
    echo 'Configure the roles that can access user data.';
}

function user_data_roles_callback() {
    $roles = get_editable_roles();
    $selected_roles = get_option('user_data_roles', []);
    foreach ($roles as $role_name => $role_info) {
        $checked = in_array($role_name, $selected_roles) ? 'checked' : '';
        echo '<label><input type="checkbox" name="user_data_roles[]" value="' . esc_attr($role_name) . '" ' . $checked . '> ' . esc_html($role_info['name']) . '</label><br>';
    }
}

add_shortcode('display_user_data', 'display_user_data_shortcode');

//JavaScript để chọn tất cả checkbox
add_action('admin_footer', 'add_select_all_script');
function add_select_all_script() {
    echo '<script type="text/javascript">
    jQuery(document).ready(function($) {
        $("#select_all").click(function() {
            $("input[name=\'data_ids[]\']").prop("checked", this.checked);
        });
    });
    </script>';
}

// Shortcode display_user_data
function display_user_data_shortcode() {
    ob_start();
    display_user_data();
    return ob_get_clean();
}
add_shortcode('display_user_data', 'display_user_data_shortcode');

// Shortcode [display_realtime_chart]
function display_realtime_chart() {
    ob_start();
    ?>
    <canvas id="realtimeChart" width="400" height="200"></canvas>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var ctx = document.getElementById('realtimeChart').getContext('2d');
            var realtimeChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Số lượt truy cập (Realtime)',
                        data: [],
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            function updateRealtimeChart() {
                fetch('<?php echo esc_url(rest_url('user-data/v1/current')); ?>')
                    .then(response => response.json())
                    .then(data => {
                        var currentTime = new Date().toLocaleTimeString();
                        realtimeChart.data.labels.push(currentTime);
                        realtimeChart.data.datasets[0].data.push(data);
                        if (realtimeChart.data.labels.length > 10) {
                            realtimeChart.data.labels.shift();
                            realtimeChart.data.datasets[0].data.shift();
                        }
                        realtimeChart.update();
                    });
            }

            setInterval(updateRealtimeChart, 3000);
        });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('realtime_chart', 'display_realtime_chart');

// Shortcode [display_daily_chart]
function display_daily_chart() {
    ob_start();
    ?>
    <canvas id="dailyChart" width="400" height="200"></canvas>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var ctx = document.getElementById('dailyChart').getContext('2d');
            var dailyChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Số lượt truy cập (Theo ngày)',
                        data: [],
                        backgroundColor: 'rgba(153, 102, 255, 0.2)',
                        borderColor: 'rgba(153, 102, 255, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            fetch('<?php echo esc_url(rest_url('user-data/v1/daily')); ?>')
                .then(response => response.json())
                .then(data => {
                    data.forEach(item => {
                        dailyChart.data.labels.push(item.date);
                        dailyChart.data.datasets[0].data.push(item.count);
                    });
                    dailyChart.update();
                });
        });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('daily_chart', 'display_daily_chart');

?>